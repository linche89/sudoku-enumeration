#include <bits/stdc++.h>
using namespace std;
int main(){
  const int C=6,K=3,N=12,T=6;
  vector<int> subs;
  for(int m=0;m<(1<<C);m++) if(__builtin_popcount((unsigned)m)==K) subs.push_back(m);
  int idx[64]; fill(begin(idx),end(idx),-1); for(int i=0;i<20;i++) idx[subs[i]]=i;
  vector<array<int,6>> perms; array<int,6> p={0,1,2,3,4,5}; do{perms.push_back(p);}while(next_permutation(p.begin(),p.end()));
  vector<array<int,20>> acts(720);
  for(int q=0;q<720;q++)for(int i=0;i<20;i++){
    int mm=0;for(int a=0;a<6;a++)if(subs[i]>>a&1)mm|=1<<perms[q][a];
    acts[q][i]=idx[mm];
  }
  vector<array<unsigned char,20>> occs;
  array<unsigned char,20> cur{}; array<int,6> deg; deg.fill(T);
  function<void(int,int)> rec=[&](int i,int rem){
    if(i==20){if(rem==0){for(int a=0;a<6;a++)if(deg[a]!=0)return;occs.push_back(cur);}return;}
    int mm=subs[i], mx=rem;for(int a=0;a<6;a++)if(mm>>a&1)mx=min(mx,deg[a]);
    for(int x=0;x<=mx;x++){
      cur[i]=x;for(int a=0;a<6;a++)if(mm>>a&1)deg[a]-=x;
      rec(i+1,rem-x);
      for(int a=0;a<6;a++)if(mm>>a&1)deg[a]+=x;
    }
    cur[i]=0;
  };
  rec(0,N); cerr<<"occ="<<occs.size()<<"\n";
  // encode counts 0..12 in 5 bits each into two uint64s for canonical hash
  struct Key{uint64_t a,b; bool operator==(Key const&o)const{return a==o.a&&b==o.b;}};
  struct Hash{size_t operator()(Key const&k)const{return k.a^(k.b*0x9e3779b97f4a7c15ULL);}};
  auto encode=[&](array<unsigned char,20> const&v){Key k{0,0};for(int i=0;i<12;i++)k.a|=uint64_t(v[i])<<(5*i);for(int i=12;i<20;i++)k.b|=uint64_t(v[i])<<(5*(i-12));return k;};
  unordered_set<Key,Hash> reps; reps.reserve(10000);
  array<unsigned char,20> tmp{};
  for(auto const&v:occs){
    Key best{~0ULL,~0ULL};
    for(int q=0;q<720;q++){
      tmp.fill(0);for(int i=0;i<20;i++)tmp[acts[q][i]]=v[i];
      Key k=encode(tmp);
      if(k.a<best.a || (k.a==best.a && k.b<best.b))best=k;
    }
    reps.insert(best);
  }
  cout<<reps.size()<<"\n";
}
