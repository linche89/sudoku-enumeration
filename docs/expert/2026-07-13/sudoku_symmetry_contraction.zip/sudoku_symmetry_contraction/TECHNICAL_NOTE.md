# Exact 3+3 symmetry contraction for the 2 x 6 coefficient

This note records the exact reduction, representation data, and validation
certificates produced for

\[
N(6)=[\Omega_x\Omega_y]\Phi_6(x,y)^{12}.
\]

It does **not** claim an independent evaluation of `N(6)`.  Its main result is
an exact block contraction and exact evidence that the hoped-for low channel
rank is absent in the two smaller nontrivial tests.

## 1. Half-boundary map

Let `G=S_12` and let `C` be the 462 unordered balanced cuts of the 12
symbols.  Put `W=Q[C]`.  Split the six band rows into two groups of three.
Let

\[
\mathcal X=\{(S_1,\ldots,S_{12}):S_s\in { [6]\choose 3},\ 
 |\{s:a\in S_s\}|=6\ (a=1,\ldots,6)\}.
\]

For a triple `a=(c_1,c_2,c_3)` of cuts, define `u_a in Q[X]` by letting
`u_a(S_1,...,S_12)` be the number of arrays `q_{rs} in [6]` such that

* `{q_{1s},q_{2s},q_{3s}}=S_s` for every symbol `s`;
* the three colors at a symbol are distinct;
* for each row `r`, the map `s -> (c_r(s),q_{rs})` is a bijection from the
  symbols to `{0,1} x [6]`.

Let `J` complement every 3-subset.  For two half-skeletons `a,d`, the
one-stack completion count is

\[
F(a,d)=\langle u_a,J u_d\rangle.
\]

The map `a -> u_a` is invariant under permuting the three rows and under
reorienting any cut.  Hence it factors through

\[
D=\operatorname{Sym}^3 W,\qquad \dim D={464\choose3}=16,542,064.
\]

Writing `U:D -> Q[X]` for this map and `M=U^* J U`, with the inherited inner
product from `W^{\otimes3}`, gives the exact identity

\[
\boxed{N(6)=2^6\,\|M\|_{HS}^2.}
\]

The factor `2^6` restores the two orientations of each of the six unordered
cuts.

In a divided-power basis indexed by multiplicity vectors `(n_c)` with
`sum n_c=3`, the Gram diagonal is `3!/prod_c n_c!`.  This is the convenient
basis for modular arithmetic.

## 2. S_12 blocks

For a permutation with cycle type `mu`, the character of `W` is

\[
\chi_W(\mu)=\frac12\left([z^6]\prod_{l\in\mu}(1+z^l)
 +1_{\text{all }l\text{ even}}2^{\ell(\mu)}\right).
\]

Thus

\[
\chi_D(g)=\frac{\chi_W(g)^3+3\chi_W(g)\chi_W(g^2)+2\chi_W(g^3)}6.
\]

Murnaghan--Nakayama decomposition gives

* 67 nonzero irreducible types;
* `sum d_lambda m_lambda = 16,542,064`;
* `sum m_lambda = 6,206`;
* `max m_lambda = 344`;
* `sum m_lambda^2 = 1,081,862`;
* `sum m_lambda^3 = 242,094,680`;
* `sum m_lambda(m_lambda+1)/2 = 544,034`.

Under

\[
D=\bigoplus_\lambda S^\lambda\otimes Q^{m_\lambda},
\]

Schur's lemma gives

\[
M=\bigoplus_\lambda I_{d_\lambda}\otimes M_\lambda,
\qquad
N(6)=64\sum_\lambda d_\lambda\operatorname{tr}(M_\lambda M_\lambda^T).
\]

The final norm therefore needs at most 544,034 stored field elements for the
symmetric blocks (about 4.15 MiB with 64-bit residues) and fewer than 1.1
million modular multiply-adds.  Building the blocks, not contracting them, is
the hard step.

## 3. Exact multiplicity bases and projectors

A half-skeleton is represented by a histogram `h_u`, `u in {0,1}^3`, with
three margins equal to six, modulo `C_2^3 semidirect S_3`.  There are exactly
17 orbits.  If `H_alpha <= S_12` is the stabilizer of a representative, then

\[
D \cong \bigoplus_{\alpha=1}^{17} Q[G/H_\alpha].
\]

For each `lambda`, a multiplicity basis is

\[
\mathcal M_\lambda=\bigoplus_\alpha (S^\lambda)^{H_\alpha}.
\]

It can be constructed over any prime `p>12` by solving
`(rho_lambda(s)-I)v=0` for generators `s` of `H_alpha` in an integral Specht
(or Murphy) basis.  Equivalently, use the Reynolds projector

\[
R_{\lambda,\alpha}=|H_\alpha|^{-1}\sum_{h\in H_\alpha}\rho_\lambda(h).
\]

The isotypic projector is

\[
E_\lambda={d_\lambda\over12!}\sum_{g\in S_{12}}
 \chi^\lambda(g^{-1})\rho_D(g).
\]

For a `G`-adapted isometry
`T_lambda:S^lambda tensor Q^{m_lambda} -> D`, the block is explicitly

\[
M_\lambda={1\over d_\lambda}\operatorname{Tr}_{S^\lambda}
 \left(T_\lambda^*U^*JUT_\lambda\right).
\]

With a nonorthogonal modular multiplicity basis having Gram matrix `G_lambda`,
replace the Frobenius term by

\[
\operatorname{tr}(G_\lambda^{-1}M_\lambda^T
 G_\lambda M_\lambda).
\]

No square roots are needed.

## 4. Why this is not yet a low-rank N(6) algorithm

The balanced midpoint module after color averaging has dimension

\[
\dim (Q[\mathcal X])^{S_6}=5,171,942,314.
\]

Every one of the 67 multiplicities occurring in `D` fits inside the
corresponding boundary multiplicity.  Thus representation dimensions force
no kernel at all.

There are 49,755 balanced occupancy vectors `(m_S)`, and 132 occupancy orbits
under color permutations.  These do not determine `u_alpha`: its value also
depends on the relative alignment between the occupancy classes and the eight
symbol pattern cells of the half-skeleton.  Consequently 132 is not a valid
channel count.

The full six-row symmetry constrains the 544,034 symmetric block coordinates
to a 63,199-dimensional subspace, but constructing that subspace coefficient
by coefficient is precisely the outer-skeleton enumeration to be avoided.

## 5. Full-rank validation in smaller cases

### C=4

The exact 2+2 map has

* `dim Sym^2(W_8)=630`;
* exact boundary states 44,730 and 1,890 color orbits;
* `N(4)=29,136,487,207,403,520`;
* rank of `U^*JU` modulo 1,000,003 equal to 630.

A full modular rank proves full rank over `Q`.

The nonzero multiplicities, and hence measured block ranks, are

```
(8):3, (7,1):1, (6,2):5, (5,3):1, (5,2,1):2,
(4,4):4, (4,3,1):1, (4,2,2):3,
(3,3,1,1):1, (2,2,2,2):1.
```

### C=5

An independent exact 2+3 meet-in-the-middle check returns

\[
N(5)=1,903,816,047,972,624,930,994,913,280,000.
\]

Here `D_2=Sym^2(W_10)` has dimension 8,001 and
`End_{S_10}(D_2)` has dimension 154.  The matrix of left multiplication by
the exact Gram operator in this 154-dimensional orbital algebra has rank
154 modulo 1,000,003.  Hence every isotypic block is invertible and the cross
map has full row rank 8,001 over `Q`.

The measured block ranks are

```
(10):3, (9,1):2, (8,2):6, (7,3):3, (7,2,1):3,
(6,4):6, (6,3,1):3, (6,2,2):4, (5,4,1):3,
(5,3,2):2, (5,3,1,1):1, (5,2,2,1):1,
(4,4,2):3, (4,3,2,1):1, (4,2,2,2):1.
```

The C=5 program uses the 355 full-skeleton orbits only as a validation
harness; it is not proposed as the C=6 engine.

## 6. Local cut/matching transform

Let `P` range over the 10,395 perfect matchings of the 12 symbols and let
`B(P,c)=1` when `P` crosses cut `c`.  If
`i=min(|S cap T|,6-|S cap T|)`, then

\[
(B^TB)_{c,d}=i!(6-i)!.
\]

Its four eigenvalues on the four summands of `W` are

```
S^(12): 23040,  S^(10,2): 1920,
S^(8,4): 576,   S^(6,6): 360.
```

Thus the local transform already has full rank 462.  Its spectral projectors
are the Lagrange polynomials in `B^TB` associated with these four eigenvalues.

## 7. CRT

A rigorous coefficient bound is

\[
0\le N(6)<\bigl(64(6!)^2\bigr)^{12}=33,177,600^{12}<2^{300}.
\]

Five suitably chosen 61-bit primes whose product exceeds this bound suffice
for reconstruction; a sixth prime is a useful independent checksum.  Use
unnormalized projectors and divided-power Gram matrices, and take primes
larger than 12, so all group and stabilizer orders are invertible.

## Conclusion

The 3+3 contraction has a clean exact block form and a very cheap final norm,
but no independently buildable low-rank construction of the C=6 blocks was
found.  The C=4 and C=5 maps are exactly full rank, while the C=6 boundary
contains every domain multiplicity.  Thus the available evidence is against
the proposed small-channel mechanism rather than in favor of it.
