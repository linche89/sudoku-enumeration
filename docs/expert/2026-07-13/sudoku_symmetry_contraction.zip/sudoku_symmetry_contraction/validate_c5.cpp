#include <bits/stdc++.h>
using namespace std;
static const int C=5,N=10;

struct U64Hash { size_t operator()(uint64_t x) const { x += 0x9e3779b97f4a7c15ULL; x=(x^(x>>30))*0xbf58476d1ce4e5b9ULL; x=(x^(x>>27))*0x94d049bb133111ebULL; return x^(x>>31); } };

vector<array<int,C>> perms;
int pairCode[C][C], maskCode[1<<C];
array<pair<int,int>,10> codePair;

uint64_t packDigits(const int d[N]) { uint64_t x=0; for(int s=0;s<N;s++) x=(x<<4)|uint64_t(d[s]); return x; }
void unpackDigits(uint64_t x,int d[N]) { for(int s=N-1;s>=0;s--){d[s]=x&15;x>>=4;} }

uint64_t canonicalColor(uint64_t code){
    int d[N]; unpackDigits(code,d); uint16_t sig[C]={};
    for(int s=0;s<N;s++){auto [a,b]=codePair[d[s]];uint16_t bit=uint16_t(1u<<(N-1-s));sig[a]|=bit;sig[b]|=bit;}
    array<int,C> ord={0,1,2,3,4};
    stable_sort(ord.begin(),ord.end(),[&](int a,int b){return sig[a]<sig[b];});
    int mp[C];for(int i=0;i<C;i++)mp[ord[i]]=i;
    int z[N];for(int s=0;s<N;s++){auto [a,b]=codePair[d[s]];z[s]=pairCode[mp[a]][mp[b]];}
    return packDigits(z);
}
uint64_t bruteCanonical(uint64_t code){
    int d[N];unpackDigits(code,d);uint64_t best=~0ULL;
    for(auto &p:perms){int z[N];for(int s=0;s<N;s++){auto [a,b]=codePair[d[s]];z[s]=pairCode[p[a]][p[b]];}best=min(best,packDigits(z));}return best;
}
int orbitSize(uint64_t code){
    int d[N];unpackDigits(code,d);int aut=0;
    for(auto &p:perms){bool ok=true;for(int s=0;s<N;s++){auto [a,b]=codePair[d[s]];if(pairCode[p[a]][p[b]]!=d[s]){ok=false;break;}}if(ok)aut++;}
    return 120/aut;
}

vector<vector<int>> halfTypeReps(int k){
    int P=1<<k; vector<vector<int>> sols;
    vector<int> cur(P),marg(k);
    function<void(int,int)> rec=[&](int i,int rem){
        if(i==P-1){int x=rem;for(int r=0;r<k;r++)if((i>>r)&1)marg[r]+=x;bool ok=true;for(int r=0;r<k;r++)if(marg[r]!=C)ok=false;if(ok){cur[i]=x;sols.push_back(cur);}for(int r=0;r<k;r++)if((i>>r)&1)marg[r]-=x;return;}
        int mx=rem;for(int r=0;r<k;r++)if((i>>r)&1)mx=min(mx,C-marg[r]);
        for(int x=0;x<=mx;x++){cur[i]=x;for(int r=0;r<k;r++)if((i>>r)&1)marg[r]+=x;rec(i+1,rem-x);for(int r=0;r<k;r++)if((i>>r)&1)marg[r]-=x;}cur[i]=0;
    };rec(0,N);
    set<vector<int>> reps;
    vector<int> perm(k);iota(perm.begin(),perm.end(),0);
    for(auto &h:sols){vector<int> best(P,99);sort(perm.begin(),perm.end());do{for(int flip=0;flip<P;flip++){vector<int> z(P);for(int pat=0;pat<P;pat++){int q=0;for(int r=0;r<k;r++){int b=((pat>>perm[r])&1)^((flip>>r)&1);q|=b<<r;}z[q]=h[pat];}best=min(best,z);}}while(next_permutation(perm.begin(),perm.end()));reps.insert(best);}
    return vector<vector<int>>(reps.begin(),reps.end());
}
vector<int> cutsFromHist(const vector<int>&h,int k){
    vector<int> cuts(k,0);int s=0;for(int pat=0;pat<(1<<k);pat++)for(int q=0;q<h[pat];q++,s++)for(int r=0;r<k;r++)if((pat>>r)&1)cuts[r]|=1<<s;assert(s==N);return cuts;
}

vector<uint32_t> allAssignments(int cut){
    vector<int>A,B;for(int s=0;s<N;s++)(((cut>>s)&1)?A:B).push_back(s);
    vector<uint32_t> out;out.reserve(14400);
    for(auto &pa:perms)for(auto &pb:perms){uint32_t x=0;for(int i=0;i<C;i++){x|=uint32_t(pa[i])<<(3*A[i]);x|=uint32_t(pb[i])<<(3*B[i]);}out.push_back(x);}return out;
}
vector<uint32_t> normAssignments(int cut){
    vector<int>A,B;for(int s=0;s<N;s++)(((cut>>s)&1)?A:B).push_back(s);
    vector<uint32_t> out;out.reserve(120);
    for(auto &pb:perms){uint32_t x=0;for(int i=0;i<C;i++){x|=uint32_t(i)<<(3*A[i]);x|=uint32_t(pb[i])<<(3*B[i]);}out.push_back(x);}return out;
}
inline int col(uint32_t x,int s){return (x>>(3*s))&7;}

using Map=unordered_map<uint64_t,uint64_t,U64Hash>;
unordered_map<uint64_t,int,U64Hash> orbitCache;
int getOrbit(uint64_t c){auto it=orbitCache.find(c);if(it!=orbitCache.end())return it->second;int z=orbitSize(c);orbitCache[c]=z;return z;}

Map makePairMap(const vector<int>&cuts){
    auto X=normAssignments(cuts[0]);auto Y=allAssignments(cuts[1]);
    unordered_map<uint64_t,uint64_t,U64Hash> agg;agg.reserve(300000);
    long long paths=0;
    for(uint32_t x:X)for(uint32_t y:Y){int d[N];bool ok=true;for(int s=0;s<N;s++){int a=col(x,s),b=col(y,s);if(a==b){ok=false;break;}d[s]=pairCode[a][b];}if(!ok)continue;paths++;uint64_t can=canonicalColor(packDigits(d));agg[can]+=120;}
    Map out;out.reserve(agg.size()*2);
    for(auto &kv:agg){int os=getOrbit(kv.first);if(kv.second%os){cerr<<"pair nondiv\n";exit(4);}out[kv.first]=kv.second/os;}
    cerr<<"pair paths="<<paths<<" support="<<out.size()<<"\n";return out;
}

Map makeTripleMap(const vector<int>&cuts){
    auto X=normAssignments(cuts[0]);auto Y=allAssignments(cuts[1]);
    vector<int> G0,G1;for(int s=0;s<N;s++)(((cuts[2]>>s)&1)?G1:G0).push_back(s);
    unordered_map<uint32_t,vector<uint8_t>,U64Hash> cache0,cache1;cache0.reserve(100000);cache1.reserve(100000);
    auto valid=[&](const vector<int>&G,const int used[N],auto &cache)->const vector<uint8_t>&{
        uint32_t key=0;for(int i=0;i<C;i++)key|=uint32_t(used[G[i]])<<(5*i);
        auto it=cache.find(key);if(it!=cache.end())return it->second;
        vector<uint8_t> v;for(int pi=0;pi<120;pi++){bool ok=true;for(int i=0;i<C;i++)if(used[G[i]]&(1<<perms[pi][i])){ok=false;break;}if(ok)v.push_back(pi);}return cache.emplace(key,move(v)).first->second;
    };
    unordered_map<uint64_t,uint64_t,U64Hash> agg;agg.reserve(600000);
    long long pairpaths=0,triplepaths=0;
    for(uint32_t x:X)for(uint32_t y:Y){int used[N];bool ok=true;for(int s=0;s<N;s++){int a=col(x,s),b=col(y,s);if(a==b){ok=false;break;}used[s]=(1<<a)|(1<<b);}if(!ok)continue;pairpaths++;
        auto &v0=valid(G0,used,cache0);auto &v1=valid(G1,used,cache1);
        for(uint8_t p0:v0)for(uint8_t p1:v1){int d[N];for(int i=0;i<C;i++){int s=G0[i],c=perms[p0][i];int miss=31^(used[s]|(1<<c));d[s]=maskCode[miss];s=G1[i];c=perms[p1][i];miss=31^(used[s]|(1<<c));d[s]=maskCode[miss];}triplepaths++;uint64_t can=canonicalColor(packDigits(d));agg[can]+=120;}
    }
    Map out;out.reserve(agg.size()*2);for(auto &kv:agg){int os=getOrbit(kv.first);if(kv.second%os){cerr<<"triple nondiv val="<<kv.second<<" os="<<os<<"\n";exit(5);}out[kv.first]=kv.second/os;}
    cerr<<"triple pairpaths="<<pairpaths<<" paths="<<triplepaths<<" support="<<out.size()<<" caches="<<cache0.size()<<","<<cache1.size()<<"\n";return out;
}


using U128=__uint128_t;
struct Hash128 { size_t operator()(U128 x) const { uint64_t a=(uint64_t)x,b=(uint64_t)(x>>64); return U64Hash{}(a^(b+0x9e3779b97f4a7c15ULL)); } };
string str128(U128 x){if(!x)return "0";string s;while(x){s.push_back(char('0'+x%10));x/=10;}reverse(s.begin(),s.end());return s;}

struct FullOrbit { U128 hist; int cubeOrbit; };
vector<FullOrbit> fullHistogramOrbits(){
    const int K=5,P=32; vector<U128> sols; array<int,K> marg{};
    function<void(int,int,U128)> rec=[&](int pat,int rem,U128 code){
        if(pat==P){if(rem==0){bool ok=true;for(int r=0;r<K;r++)if(marg[r]!=C)ok=false;if(ok)sols.push_back(code);}return;}
        int mx=rem;for(int r=0;r<K;r++)if((pat>>r)&1)mx=min(mx,C-marg[r]);
        for(int x=0;x<=mx;x++){for(int r=0;r<K;r++)if((pat>>r)&1)marg[r]+=x;rec(pat+1,rem-x,code|((U128)x<<(4*pat)));for(int r=0;r<K;r++)if((pat>>r)&1)marg[r]-=x;}
    };rec(0,N,0); cerr<<"full histograms="<<sols.size()<<"\n";
    unordered_map<U128,int,Hash128> id;id.reserve(sols.size()*2);for(int i=0;i<(int)sols.size();i++)id[sols[i]]=i;
    auto apply=[&](U128 code,int gen){U128 out=0;for(int pat=0;pat<P;pat++){int q=pat;if(gen<K)q=pat^(1<<gen);else{int a=gen-K,ba=(pat>>a)&1,bb=(pat>>(a+1))&1;if(ba!=bb)q=pat^((1<<a)|(1<<(a+1)));}U128 x=(code>>(4*pat))&15;out|=x<<(4*q);}return out;};
    vector<char> vis(sols.size());vector<FullOrbit> out;
    for(int i=0;i<(int)sols.size();i++)if(!vis[i]){queue<int>q;q.push(i);vis[i]=1;int sz=0;U128 best=sols[i];while(!q.empty()){int v=q.front();q.pop();sz++;best=min(best,sols[v]);for(int g=0;g<2*K-1;g++){U128 w=apply(sols[v],g);int j=id.at(w);if(!vis[j]){vis[j]=1;q.push(j);}}}out.push_back({best,sz});}
    sort(out.begin(),out.end(),[](auto&a,auto&b){return a.hist<b.hist;});cerr<<"full cube orbits="<<out.size()<<"\n";return out;
}
vector<int> decodeHist(U128 x,int k){vector<int> h(1<<k);for(int i=0;i<(1<<k);i++)h[i]=(x>>(4*i))&15;return h;}

struct HalfCan { int type; array<int,N> p; };
HalfCan canonicalizeHalf(const vector<int>&cuts,const vector<vector<int>>&types){
    int k=cuts.size(),P=1<<k;vector<int> h(P);int patOf[N];
    for(int s=0;s<N;s++){int p=0;for(int r=0;r<k;r++)if((cuts[r]>>s)&1)p|=1<<r;patOf[s]=p;h[p]++;}
    vector<int> rp(k);iota(rp.begin(),rp.end(),0);vector<int> best(P,99),bestMap(P);sort(rp.begin(),rp.end());
    do for(int flip=0;flip<P;flip++){vector<int> z(P),mp(P);for(int p=0;p<P;p++){int q=0;for(int r=0;r<k;r++){int b=((p>>rp[r])&1)^((flip>>r)&1);q|=b<<r;}mp[p]=q;z[q]=h[p];}if(z<best || (z==best && mp<bestMap)){best=z;bestMap=mp;}}while(next_permutation(rp.begin(),rp.end()));
    int type=-1;for(int i=0;i<(int)types.size();i++)if(types[i]==best){type=i;break;}if(type<0){cerr<<"half type missing\n";exit(20);}
    vector<vector<int>> actualBy(P);for(int s=0;s<N;s++)actualBy[bestMap[patOf[s]]].push_back(s);
    array<int,N> pmap{};int off=0;for(int q=0;q<P;q++){sort(actualBy[q].begin(),actualBy[q].end());if((int)actualBy[q].size()!=best[q]){cerr<<"half map mismatch\n";exit(21);}for(int j=0;j<best[q];j++)pmap[actualBy[q][j]]=off+j;off+=best[q];}if(off!=N)exit(22);
    return {type,pmap};
}

struct Entry { uint64_t code,val; };
vector<Entry> toVector(Map &&m){vector<Entry> v;v.reserve(m.size());for(auto &kv:m)v.push_back({kv.first,kv.second});sort(v.begin(),v.end(),[](auto&a,auto&b){return a.code<b.code;});return v;}
uint64_t transformBoundary(uint64_t code,const array<int,N>&pL,const array<int,N>&pR){int a[N],b[N];unpackDigits(code,a);for(int s=0;s<N;s++)b[pR[s]]=a[pL[s]];return canonicalColor(packDigits(b));}

struct ClassData { uint64_t weight; int lt,rt; array<int,N> pL,pR; };

int main(){
    array<int,C> pp={0,1,2,3,4};do{perms.push_back(pp);}while(next_permutation(pp.begin(),pp.end()));
    memset(pairCode,-1,sizeof(pairCode));fill(maskCode,maskCode+(1<<C),-1);int qq=0;for(int a=0;a<C;a++)for(int b=a+1;b<C;b++){pairCode[a][b]=pairCode[b][a]=qq;codePair[qq]={a,b};maskCode[(1<<a)|(1<<b)]=qq++;}
    mt19937_64 rng(1);for(int z=0;z<10000;z++){int d[N],e[N];for(int s=0;s<N;s++)d[s]=rng()%10;auto &rp=perms[rng()%120];for(int s=0;s<N;s++){auto [a,b]=codePair[d[s]];e[s]=pairCode[rp[a]][rp[b]];}if(canonicalColor(packDigits(d))!=canonicalColor(packDigits(e))){cerr<<"canonicalizer mismatch\n";return 2;}}

    auto pairTypes=halfTypeReps(2),tripleTypes=halfTypeReps(3);cerr<<"half types="<<pairTypes.size()<<"+"<<tripleTypes.size()<<"\n";
    auto full=fullHistogramOrbits();
    vector<ClassData> classes;classes.reserve(full.size());uint64_t totalSkeletons=0;uint64_t fact[11];fact[0]=1;for(int i=1;i<=10;i++)fact[i]=fact[i-1]*i;
    vector<vector<int>> byRT(tripleTypes.size());
    for(auto &fo:full){auto h=decodeHist(fo.hist,5);auto cuts=cutsFromHist(h,5);vector<int>L={cuts[0],cuts[1]},R={cuts[2],cuts[3],cuts[4]};auto cl=canonicalizeHalf(L,pairTypes),cr=canonicalizeHalf(R,tripleTypes);uint64_t lab=fact[10];for(int x:h)lab/=fact[x];uint64_t w=uint64_t(fo.cubeOrbit)*lab;int idx=classes.size();classes.push_back({w,cl.type,cr.type,cl.p,cr.p});byRT[cr.type].push_back(idx);totalSkeletons+=w;}
    uint64_t expected=1;for(int i=0;i<5;i++)expected*=252;cerr<<"weighted skeletons="<<totalSkeletons<<" expected="<<expected<<"\n";if(totalSkeletons!=expected)return 3;

    vector<vector<Entry>> Lmaps(pairTypes.size());
    for(int i=0;i<(int)pairTypes.size();i++){cerr<<"build pair map "<<i<<"\n";Lmaps[i]=toVector(makePairMap(cutsFromHist(pairTypes[i],2)));}

    U128 answer=0;uint64_t maxF=0;int done=0;
    for(int rt=0;rt<(int)tripleTypes.size();rt++){
        cerr<<"build triple map "<<rt<<" classes="<<byRT[rt].size()<<"\n";
        auto rv=toVector(makeTripleMap(cutsFromHist(tripleTypes[rt],3)));
        unordered_map<uint64_t,uint64_t,U64Hash> rh;rh.reserve(rv.size()*2);for(auto&e:rv)rh[e.code]=e.val;
        for(int ci:byRT[rt]){
            auto &cd=classes[ci];uint64_t F=0;for(auto &e:Lmaps[cd.lt]){uint64_t z=transformBoundary(e.code,cd.pL,cd.pR);auto it=rh.find(z);if(it!=rh.end())F += uint64_t(getOrbit(e.code))*e.val*it->second;}
            maxF=max(maxF,F);answer += U128(cd.weight)*F*F;done++;if(done%50==0)cerr<<"classes done="<<done<<" partial="<<str128(answer)<<"\n";
        }
    }
    cout<<"classes="<<classes.size()<<" maxF="<<maxF<<"\n";
    cout<<"N5="<<str128(answer)<<"\n";
    return 0;
}
