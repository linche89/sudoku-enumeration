#include <bits/stdc++.h>
using namespace std;
static const int C=4,N=8;
static const int MOD=1000003;

static string u128str(__uint128_t x){
    if(!x) return "0"; string s; while(x){s.push_back('0'+x%10);x/=10;} reverse(s.begin(),s.end());return s;
}

int main(){
    vector<array<int,C>> perms;
    array<int,C> p={0,1,2,3};
    do{perms.push_back(p);}while(next_permutation(p.begin(),p.end()));

    int paircode[C][C]; memset(paircode,-1,sizeof(paircode));
    vector<pair<int,int>> codepair;
    for(int a=0;a<C;a++) for(int b=a+1;b<C;b++){
        paircode[a][b]=paircode[b][a]=(int)codepair.size();
        codepair.push_back({a,b});
    }
    const int Q=codepair.size(); // 6
    int compPair[Q];
    for(int q=0;q<Q;q++){
        vector<int> z;
        for(int a=0;a<C;a++) if(a!=codepair[q].first && a!=codepair[q].second) z.push_back(a);
        compPair[q]=paircode[z[0]][z[1]];
    }
    int pairperm[24][Q];
    for(int q=0;q<24;q++) for(int a=0;a<C;a++) for(int b=a+1;b<C;b++){
        int aa=perms[q][a],bb=perms[q][b];
        pairperm[q][paircode[a][b]]=paircode[aa][bb];
    }

    int powQ[N+1]; powQ[0]=1; for(int i=1;i<=N;i++)powQ[i]=powQ[i-1]*Q;
    int totalcodes=powQ[N];
    vector<int> canon(totalcodes,-1), canonicalCode;
    unordered_map<int,int> rowmap; rowmap.reserve(5000);
    vector<int> orbitSize;

    for(int code=0;code<totalcodes;code++){
        int z=code, digs[N], deg[C]={};
        for(int s=0;s<N;s++){
            int d=z%Q; z/=Q; digs[s]=d;
            auto [a,b]=codepair[d]; deg[a]++;deg[b]++;
        }
        bool ok=true; for(int a=0;a<C;a++) if(deg[a]!=C) ok=false;
        if(!ok) continue;
        int best=INT_MAX;
        for(int q=0;q<24;q++){
            int v=0;
            for(int s=N-1;s>=0;s--) v=v*Q+pairperm[q][digs[s]];
            best=min(best,v);
        }
        auto [it,ins]=rowmap.emplace(best,(int)rowmap.size());
        int id=it->second;
        if(ins){canonicalCode.push_back(best);orbitSize.push_back(0);} 
        canon[code]=id; orbitSize[id]++;
    }
    int R=rowmap.size();
    cerr << "boundary color orbits="<<R<<" exact states="
         << accumulate(orbitSize.begin(),orbitSize.end(),0LL)<<"\n";

    vector<int> complementRow(R,-1);
    for(int r=0;r<R;r++){
        int z=canonicalCode[r], code2=0,mul=1;
        for(int s=0;s<N;s++){
            int d=z%Q;z/=Q; code2 += compPair[d]*mul; mul*=Q;
        }
        complementRow[r]=canon[code2];
        if(complementRow[r]<0){cerr<<"bad complement\n";return 2;}
    }

    // 35 unordered balanced cuts, represented by the member containing symbol 0.
    vector<int> cuts;
    for(int m=0;m<(1<<N);m++) if(__builtin_popcount((unsigned)m)==C && (m&1)) cuts.push_back(m);
    cerr << "cuts="<<cuts.size()<<"\n";

    // A row assignment is a color map symbols -> [4], bijective within each side of the cut.
    vector<vector<uint16_t>> asg(cuts.size()), asgNorm(cuts.size());
    for(int ci=0;ci<(int)cuts.size();ci++){
        vector<int>A,B;
        for(int s=0;s<N;s++) (((cuts[ci]>>s)&1)?A:B).push_back(s);
        for(auto &pa:perms) for(auto &pb:perms){
            uint16_t x=0;
            for(int i=0;i<C;i++){
                x |= (uint16_t(pa[i])<<(2*A[i]));
                x |= (uint16_t(pb[i])<<(2*B[i]));
            }
            asg[ci].push_back(x);
        }
        // Divide out the free global S_4 color action by fixing colors on A in symbol order.
        for(auto &pb:perms){
            uint16_t x=0;
            for(int i=0;i<C;i++){
                x |= (uint16_t(i)<<(2*A[i]));
                x |= (uint16_t(pb[i])<<(2*B[i]));
            }
            asgNorm[ci].push_back(x);
        }
    }

    vector<pair<int,int>> cols;
    vector<int> colMultiplicity;
    for(int i=0;i<(int)cuts.size();i++) for(int j=i;j<(int)cuts.size();j++){
        cols.push_back({i,j}); colMultiplicity.push_back(i==j?1:2);
    }
    int M=cols.size();
    cerr << "Sym^2(W) columns="<<M<<"\n";

    // agg[r,c] = sum of u_c(x) over all exact boundary words in color orbit r.
    vector<vector<uint32_t>> agg(R,vector<uint32_t>(M,0));
    for(int col=0;col<M;col++){
        auto [i,j]=cols[col];
        for(uint16_t x:asgNorm[i]) for(uint16_t y:asg[j]){
            bool ok=true; int code=0,mul=1;
            for(int s=0;s<N;s++){
                int a=(x>>(2*s))&3, b=(y>>(2*s))&3;
                if(a==b){ok=false;break;}
                code += paircode[a][b]*mul; mul*=Q;
            }
            if(ok){
                int r=canon[code]; if(r<0){cerr<<"invalid boundary\n";return 3;}
                agg[r][col]+=24; // restore the factored global color permutations
            }
        }
    }

    // U is constant on each color orbit; recover that common exact value.
    vector<vector<pair<int,uint32_t>>> sparse(R);
    long long nnz=0;
    for(int r=0;r<R;r++) for(int c=0;c<M;c++) if(agg[r][c]){
        if(agg[r][c] % orbitSize[r]){
            cerr<<"nonintegral orbit value r="<<r<<" c="<<c<<" agg="<<agg[r][c]<<" os="<<orbitSize[r]<<"\n";
            return 4;
        }
        uint32_t u=agg[r][c]/orbitSize[r];
        sparse[r].push_back({c,u}); nnz++;
    }
    cerr << "U nonzeros="<<nnz<<" density="<<setprecision(4)
         <<double(nnz)/(double(R)*M)<<"\n";

    // F = U^T J U, exact on boundary words. Traverse color orbits with orbit-size weights.
    vector<unsigned long long> F((size_t)M*M,0);
    for(int r=0;r<R;r++){
        int t=complementRow[r];
        unsigned long long w=orbitSize[r];
        for(auto [i,ui]:sparse[r]) for(auto [j,uj]:sparse[t]){
            F[(size_t)i*M+j] += w*(unsigned long long)ui*uj;
        }
    }
    for(int i=0;i<M;i++) for(int j=0;j<M;j++) if(F[(size_t)i*M+j]!=F[(size_t)j*M+i]){
        cerr<<"F not symmetric\n"; return 5;
    }

    __uint128_t orderedHalfNorm=0;
    for(int i=0;i<M;i++) for(int j=0;j<M;j++){
        __uint128_t f=F[(size_t)i*M+j];
        orderedHalfNorm += (__uint128_t)colMultiplicity[i]*colMultiplicity[j]*f*f;
    }
    __uint128_t N4=orderedHalfNorm*16; // two orientations for each of four cuts/rows
    cout << "half_norm="<<u128str(orderedHalfNorm)<<"\n";
    cout << "N4="<<u128str(N4)<<"\n";

    // Rank of F modulo a prime, to test whether U^* J U is nonsingular.
    vector<vector<int>> A(M,vector<int>(M));
    for(int i=0;i<M;i++)for(int j=0;j<M;j++)A[i][j]=F[(size_t)i*M+j]%MOD;
    auto modpow=[](long long a,int e){long long r=1;while(e){if(e&1)r=r*a%MOD;a=a*a%MOD;e>>=1;}return (int)r;};
    int rank=0;
    for(int c=0;c<M && rank<M;c++){
        int piv=-1;for(int r=rank;r<M;r++)if(A[r][c]){piv=r;break;}
        if(piv<0)continue;
        swap(A[piv],A[rank]);
        int inv=modpow(A[rank][c],MOD-2);
        for(int j=c;j<M;j++)A[rank][j]=(long long)A[rank][j]*inv%MOD;
        for(int r=rank+1;r<M;r++) if(A[r][c]){
            int q=A[r][c];
            for(int j=c;j<M;j++){
                int v=A[r][j]-(long long)q*A[rank][j]%MOD;
                if(v<0)v+=MOD; A[r][j]=v;
            }
        }
        rank++;
    }
    cout << "rank_F_mod_"<<MOD<<"="<<rank<<"\n";
    return 0;
}
