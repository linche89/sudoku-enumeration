# Exact symmetry-contraction checks for 2 x C Sudoku

This directory contains reproducible exact computations supporting the
3+3 contraction analysis.

## Build and run

```bash
g++ -O3 -std=c++17 validate_c4.cpp -o validate_c4
./validate_c4

g++ -O3 -std=c++17 validate_c5.cpp -o validate_c5
./validate_c5

g++ -O3 -std=c++17 rank_channels_c5.cpp -o rank_channels_c5
./rank_channels_c5

python3 symmetry_blocks.py --boundary --csv c6_block_multiplicities.csv

g++ -O3 -std=c++17 count_boundary_occupancy_orbits.cpp -o count_occ
./count_occ
```

`validate_c5` uses the 355 C=5 full-skeleton orbits only as an independent
validation harness. It is not proposed as the C=6 algorithm.

## What is certified

* `validate_c4` evaluates the exact 2+2 half-boundary contraction, reproduces
  `N(4)`, and proves modulo 1,000,003 that `U^* J U` has full rank 630.
* `validate_c5` evaluates an exact 2+3 meet-in-the-middle contraction and
  reproduces `N(5)`.
* `rank_channels_c5` forms the 154-dimensional orbital algebra of
  `End_{S_10}(Sym^2 W)` and proves that the C=5 cross-contraction has full
  row rank 8,001. Full modular rank is an exact certificate over Q.
* `symmetry_blocks.py` computes the complete C=6 decomposition of
  `Sym^3 W` with Murnaghan--Nakayama and, with `--boundary`, the color-
  invariant midpoint character by Burnside averaging.
* `count_boundary_occupancy_orbits.cpp` checks that there are 49,755
  balanced multisets of 3-subsets and 132 orbits under S_6.
