#!/usr/bin/env python3
"""Exact character calculations for the 3+3 contraction at C=6.

No Sage/GAP dependency.  Irreducible S_n characters are computed with
Murnaghan--Nakayama.  The script prints the decomposition of
D = Sym^3(W), where W is the permutation module on unordered 6|6 cuts,
and optionally the color-invariant boundary-module multiplicities.
"""
from __future__ import annotations
from collections import Counter
from fractions import Fraction
from functools import lru_cache
from itertools import combinations, permutations, product
from math import factorial, gcd
import argparse
import csv


def partitions(n: int, max_part: int | None = None):
    if n == 0:
        yield ()
        return
    max_part = n if max_part is None else min(max_part, n)
    for first in range(max_part, 0, -1):
        for rest in partitions(n - first, min(first, n - first) if n - first else 0):
            yield (first,) + rest


def contains(lam, nu):
    return all((nu[i] if i < len(nu) else 0) <= (lam[i] if i < len(lam) else 0)
               for i in range(max(len(lam), len(nu))))


def border_strip_height(lam, nu):
    cells = {(i, j) for i, row in enumerate(lam)
             for j in range(nu[i] if i < len(nu) else 0, row)}
    if not cells:
        return None
    seen = {next(iter(cells))}
    stack = list(seen)
    while stack:
        i, j = stack.pop()
        for q in ((i-1, j), (i+1, j), (i, j-1), (i, j+1)):
            if q in cells and q not in seen:
                seen.add(q)
                stack.append(q)
    if len(seen) != len(cells):
        return None
    for i, j in cells:
        if {(i,j), (i+1,j), (i,j+1), (i+1,j+1)} <= cells:
            return None
    return len({i for i, _ in cells})


@lru_cache(None)
def removals(lam, k):
    out = []
    for nu in partitions(sum(lam) - k):
        if contains(lam, nu):
            h = border_strip_height(lam, nu)
            if h is not None:
                out.append((nu, (-1) ** (h - 1)))
    return tuple(out)


@lru_cache(None)
def character(lam, mu):
    if not mu:
        return int(not lam)
    return sum(sign * character(nu, mu[1:]) for nu, sign in removals(lam, mu[0]))


def z_mu(mu):
    z = 1
    for length, multiplicity in Counter(mu).items():
        z *= length ** multiplicity * factorial(multiplicity)
    return z


def hook_dimension(lam):
    hooks = 1
    for i, row in enumerate(lam):
        for j in range(row):
            hooks *= (row - j - 1
                      + sum(1 for r in range(i+1, len(lam)) if lam[r] > j)
                      + 1)
    return factorial(sum(lam)) // hooks


def power_cycle_type(mu, k):
    out = []
    for length in mu:
        d = gcd(length, k)
        out.extend([length // d] * d)
    return tuple(sorted(out, reverse=True))


def subset_coefficient(mu, target):
    dp = [0] * (target + 1)
    dp[0] = 1
    for length in mu:
        for s in range(target - length, -1, -1):
            dp[s + length] += dp[s]
    return dp[target]


def chi_W(mu):
    # Fixed unordered balanced cuts: fixed setwise plus swapped with complement.
    a = subset_coefficient(mu, 6)
    b = 2 ** len(mu) if all(length % 2 == 0 for length in mu) else 0
    return (a + b) // 2


def chi_D(mu):
    a = chi_W(mu)
    b = chi_W(power_cycle_type(mu, 2))
    c = chi_W(power_cycle_type(mu, 3))
    return (a**3 + 3*a*b + 2*c) // 6


def multiplicities(char_values, n=12):
    p = list(partitions(n))
    result = {}
    for lam in p:
        value = sum(Fraction(character(lam, mu) * char_values[mu], z_mu(mu)) for mu in p)
        assert value.denominator == 1
        if value:
            result[lam] = value.numerator
    return result


def permutation_from_cycle_type(mu):
    p = list(range(sum(mu)))
    start = 0
    for length in mu:
        cyc = list(range(start, start + length))
        for i, a in enumerate(cyc):
            p[a] = cyc[(i + 1) % length]
        start += length
    return tuple(p)


SUBSETS_3_OF_6 = [sum(1 << a for a in c) for c in combinations(range(6), 3)]


def fixed_boundary_count(mu, nu):
    """# balanced 3-subset words fixed by (g,tau), types mu and nu."""
    tau = permutation_from_cycle_type(nu)
    poly = {(0,0,0,0,0,0): 1}
    for length in mu:
        choices = []
        for subset in SUBSETS_3_OF_6:
            current = subset
            degree = [0] * 6
            for _ in range(length):
                for a in range(6):
                    if current >> a & 1:
                        degree[a] += 1
                nxt = 0
                for a in range(6):
                    if current >> a & 1:
                        nxt |= 1 << tau[a]
                current = nxt
            if current == subset and all(x <= 6 for x in degree):
                choices.append(tuple(degree))
        nxt_poly = {}
        for old, coeff in poly.items():
            for degree in choices:
                new = tuple(old[a] + degree[a] for a in range(6))
                if all(x <= 6 for x in new):
                    nxt_poly[new] = nxt_poly.get(new, 0) + coeff
        poly = nxt_poly
    return poly.get((6,6,6,6,6,6), 0)


def boundary_character():
    # H=(Q[X])^{S_6}; Burnside average over the color action.
    p12, p6 = list(partitions(12)), list(partitions(6))
    out = {}
    for mu in p12:
        value = sum(Fraction(fixed_boundary_count(mu, nu), z_mu(nu)) for nu in p6)
        assert value.denominator == 1
        out[mu] = value.numerator
    return out


def half_orbits():
    pats = list(product((0,1), repeat=3))
    sols = []
    def rec(i, rem, margins, values):
        if i == 7:
            x = rem
            new = [margins[j] + x*pats[i][j] for j in range(3)]
            if new == [6,6,6]:
                sols.append(tuple(values + [x]))
            return
        mx = rem
        for j, bit in enumerate(pats[i]):
            if bit:
                mx = min(mx, 6 - margins[j])
        for x in range(mx + 1):
            rec(i+1, rem-x,
                [margins[j] + x*pats[i][j] for j in range(3)],
                values + [x])
    rec(0, 12, [0,0,0], [])
    index = {p:i for i,p in enumerate(pats)}
    group = []
    for perm in permutations(range(3)):
        for flips in product((0,1), repeat=3):
            group.append([index[tuple(p[perm[j]] ^ flips[j] for j in range(3))] for p in pats])
    orbits = {}
    for h in sols:
        images = []
        for action in group:
            z = [0] * 8
            for i, x in enumerate(h):
                z[action[i]] = x
            images.append(tuple(z))
        canonical = min(images)
        orbits.setdefault(canonical, set()).add(h)
    return [(rep, len(members)) for rep, members in sorted(orbits.items())]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--boundary', action='store_true', help='also decompose the very large boundary module')
    parser.add_argument('--csv', default='c6_block_multiplicities.csv')
    args = parser.parse_args()

    p12 = list(partitions(12))
    d_char = {mu: chi_D(mu) for mu in p12}
    d_mult = multiplicities(d_char)
    h_mult = None
    if args.boundary:
        h_mult = multiplicities(boundary_character())

    with open(args.csv, 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow(['partition', 'specht_dimension', 'multiplicity_in_Sym3W',
                    'multiplicity_in_boundary_H' if h_mult else ''])
        for lam in p12:
            if lam in d_mult:
                w.writerow(['.'.join(map(str,lam)), hook_dimension(lam), d_mult[lam],
                            h_mult.get(lam, 0) if h_mult else ''])

    print('nonzero types:', len(d_mult))
    print('dimension:', sum(hook_dimension(lam)*m for lam,m in d_mult.items()))
    print('sum multiplicities:', sum(d_mult.values()))
    print('max multiplicity:', max(d_mult.values()))
    print('sum squares:', sum(m*m for m in d_mult.values()))
    print('sum cubes:', sum(m*m*m for m in d_mult.values()))
    print('symmetric block entries:', sum(m*(m+1)//2 for m in d_mult.values()))
    print('half-skeleton orbit types:', len(half_orbits()))
    for rep, orbit_size in half_orbits():
        print(rep, 'cube-orbit-size', orbit_size)
    if h_mult:
        print('boundary dimension:', sum(hook_dimension(lam)*m for lam,m in h_mult.items()))
        assert all(h_mult[lam] >= m for lam,m in d_mult.items())
        print('all domain multiplicities fit in boundary: yes')

if __name__ == '__main__':
    main()
