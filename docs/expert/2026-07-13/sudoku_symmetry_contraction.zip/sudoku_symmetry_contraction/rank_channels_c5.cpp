#define main dont_main
#include "validate_c5.cpp"
#undef main

static const int MODP=1000003;
struct FullSystem{
  vector<FullOrbit> orbits;
  unordered_map<U128,int,Hash128> cls;
};
FullSystem buildFullSystem(){
    const int K=5,P=32;vector<U128> sols;array<int,K> marg{};
    function<void(int,int,U128)> rec=[&](int pat,int rem,U128 code){
      if(pat==P){if(rem==0){bool ok=true;for(int r=0;r<K;r++)if(marg[r]!=C)ok=false;if(ok)sols.push_back(code);}return;}
      int mx=rem;for(int r=0;r<K;r++)if((pat>>r)&1)mx=min(mx,C-marg[r]);
      for(int x=0;x<=mx;x++){for(int r=0;r<K;r++)if((pat>>r)&1)marg[r]+=x;rec(pat+1,rem-x,code|((U128)x<<(4*pat)));for(int r=0;r<K;r++)if((pat>>r)&1)marg[r]-=x;}
    };rec(0,N,0);
    unordered_map<U128,int,Hash128> id;id.reserve(sols.size()*2);for(int i=0;i<(int)sols.size();i++)id[sols[i]]=i;
    auto apply=[&](U128 code,int gen){U128 out=0;for(int pat=0;pat<P;pat++){int q=pat;if(gen<K)q=pat^(1<<gen);else{int a=gen-K,ba=(pat>>a)&1,bb=(pat>>(a+1))&1;if(ba!=bb)q=pat^((1<<a)|(1<<(a+1)));}out|=((code>>(4*pat))&15)<<(4*q);}return out;};
    vector<char>vis(sols.size());struct Tmp{U128 best;int sz;vector<int> mem;};vector<Tmp> tmp;
    for(int i=0;i<(int)sols.size();i++)if(!vis[i]){queue<int>q;q.push(i);vis[i]=1;Tmp t{sols[i],0,{}};while(!q.empty()){int v=q.front();q.pop();t.sz++;t.mem.push_back(v);t.best=min(t.best,sols[v]);for(int g=0;g<9;g++){int j=id.at(apply(sols[v],g));if(!vis[j]){vis[j]=1;q.push(j);}}}tmp.push_back(move(t));}
    sort(tmp.begin(),tmp.end(),[](auto&a,auto&b){return a.best<b.best;});FullSystem fs;fs.cls.reserve(sols.size()*2);
    for(int c=0;c<(int)tmp.size();c++){fs.orbits.push_back({tmp[c].best,tmp[c].sz});for(int i:tmp[c].mem)fs.cls[sols[i]]=c;}
    cerr<<"full classes="<<fs.orbits.size()<<" hist="<<sols.size()<<"\n";return fs;
}

struct Orb4System{
  vector<uint64_t> reps;
  unordered_map<uint64_t,int,U64Hash> cls;
};
Orb4System buildOrb4(){
 const int K=4,P=16;vector<uint64_t> sols;array<int,K>m{};
 function<void(int,int,uint64_t)>rec=[&](int pat,int rem,uint64_t code){if(pat==P){if(rem==0&&m[0]==5&&m[1]==5&&m[2]==5&&m[3]==5)sols.push_back(code);return;}int mx=rem;for(int r=0;r<K;r++)if((pat>>r)&1)mx=min(mx,5-m[r]);for(int x=0;x<=mx;x++){for(int r=0;r<K;r++)if((pat>>r)&1)m[r]+=x;rec(pat+1,rem-x,code|(uint64_t(x)<<(4*pat)));for(int r=0;r<K;r++)if((pat>>r)&1)m[r]-=x;}};rec(0,10,0);
 unordered_map<uint64_t,int,U64Hash>id;id.reserve(sols.size()*2);for(int i=0;i<(int)sols.size();i++)id[sols[i]]=i;
 vector<array<int,16>> acts;for(int flip=0;flip<16;flip++)for(int sw1=0;sw1<2;sw1++)for(int sw2=0;sw2<2;sw2++){array<int,16>a{};for(int p=0;p<16;p++){int b[4];for(int r=0;r<4;r++)b[r]=((p>>r)&1)^((flip>>r)&1);if(sw1)swap(b[0],b[1]);if(sw2)swap(b[2],b[3]);int q=0;for(int r=0;r<4;r++)q|=b[r]<<r;a[p]=q;}acts.push_back(a);}
 vector<char>vis(sols.size());struct T{uint64_t best;vector<int>mem;};vector<T>tmp;
 for(int i=0;i<(int)sols.size();i++)if(!vis[i]){queue<int>q;q.push(i);vis[i]=1;T t{sols[i],{}};while(!q.empty()){int v=q.front();q.pop();t.mem.push_back(v);t.best=min(t.best,sols[v]);for(auto&a:acts){uint64_t w=0;for(int p=0;p<16;p++)w|=((sols[v]>>(4*p))&15)<<(4*a[p]);int j=id.at(w);if(!vis[j]){vis[j]=1;q.push(j);}}}tmp.push_back(move(t));}
 sort(tmp.begin(),tmp.end(),[](auto&a,auto&b){return a.best<b.best;});Orb4System o;o.cls.reserve(sols.size()*2);for(int c=0;c<(int)tmp.size();c++){o.reps.push_back(tmp[c].best);for(int i:tmp[c].mem)o.cls[sols[i]]=c;}cerr<<"orb4="<<o.reps.size()<<" raw="<<sols.size()<<"\n";return o;
}

uint64_t hist4code(const pair<int,int>&A,const pair<int,int>&B,const vector<int>&cuts){int cnt[16]={};for(int s=0;s<N;s++){int p=((cuts[A.first]>>s)&1)|(((cuts[A.second]>>s)&1)<<1)|(((cuts[B.first]>>s)&1)<<2)|(((cuts[B.second]>>s)&1)<<3);cnt[p]++;}uint64_t z=0;for(int p=0;p<16;p++)z|=uint64_t(cnt[p])<<(4*p);return z;}
U128 hist5code(const pair<int,int>&A,const array<int,3>&B,const vector<int>&cuts){int cnt[32]={};for(int s=0;s<N;s++){int p=((cuts[A.first]>>s)&1)|(((cuts[A.second]>>s)&1)<<1)|(((cuts[B[0]]>>s)&1)<<2)|(((cuts[B[1]]>>s)&1)<<3)|(((cuts[B[2]]>>s)&1)<<4);cnt[p]++;}U128 z=0;for(int p=0;p<32;p++)z|=U128(cnt[p])<<(4*p);return z;}

int main(){
 array<int,C>pp={0,1,2,3,4};do{perms.push_back(pp);}while(next_permutation(pp.begin(),pp.end()));memset(pairCode,-1,sizeof(pairCode));fill(maskCode,maskCode+(1<<C),-1);int q=0;for(int a=0;a<C;a++)for(int b=a+1;b<C;b++){pairCode[a][b]=pairCode[b][a]=q;codePair[q]={a,b};maskCode[(1<<a)|(1<<b)]=q++;}
 auto pairTypes=halfTypeReps(2),tripleTypes=halfTypeReps(3);auto fs=buildFullSystem();
 struct CD{uint64_t weight;int lt,rt;array<int,N>pL,pR;};vector<CD> classes;vector<vector<int>>byRT(10);uint64_t fact[11];fact[0]=1;for(int i=1;i<=10;i++)fact[i]=fact[i-1]*i;
 for(auto&fo:fs.orbits){auto h=decodeHist(fo.hist,5);auto cc=cutsFromHist(h,5);auto L=canonicalizeHalf(vector<int>{cc[0],cc[1]},pairTypes),R=canonicalizeHalf(vector<int>{cc[2],cc[3],cc[4]},tripleTypes);uint64_t lab=fact[10];for(int x:h)lab/=fact[x];int idx=classes.size();classes.push_back({uint64_t(fo.cubeOrbit)*lab,L.type,R.type,L.p,R.p});byRT[R.type].push_back(idx);}
 vector<vector<Entry>>lm(3);for(int i=0;i<3;i++)lm[i]=toVector(makePairMap(cutsFromHist(pairTypes[i],2)));vector<uint64_t>Fval(355);
 for(int rt=0;rt<10;rt++){auto rv=toVector(makeTripleMap(cutsFromHist(tripleTypes[rt],3)));unordered_map<uint64_t,uint64_t,U64Hash>rh;rh.reserve(rv.size()*2);for(auto&e:rv)rh[e.code]=e.val;for(int ci:byRT[rt]){auto&cd=classes[ci];uint64_t F=0;for(auto&e:lm[cd.lt]){auto it=rh.find(transformBoundary(e.code,cd.pL,cd.pR));if(it!=rh.end())F+=uint64_t(getOrbit(e.code))*e.val*it->second;}Fval[ci]=F;}}
 cerr<<"F values ready\n";
 vector<int>cuts;unordered_map<int,int>cutidx;for(int m=0;m<(1<<N);m++)if(__builtin_popcount((unsigned)m)==5&&(m&1)){cutidx[m]=cuts.size();cuts.push_back(m);}vector<pair<int,int>>D2;unordered_map<uint64_t,int,U64Hash>d2idx;for(int i=0;i<126;i++)for(int j=i;j<126;j++){int z=D2.size();D2.push_back({i,j});d2idx[(uint64_t(i)<<32)|j]=z;}
 struct T3{array<int,3>x;uint8_t w;};vector<T3>D3;D3.reserve(341376);for(int i=0;i<126;i++)for(int j=i;j<126;j++)for(int k=j;k<126;k++){uint8_t w=(i==k?1:(i==j||j==k?3:6));D3.push_back({{i,j,k},w});}cerr<<"D2="<<D2.size()<<" D3="<<D3.size()<<"\n";
 auto o4=buildOrb4();int R=o4.reps.size();if(R!=154){cerr<<"expected154\n";return 3;}
 vector<pair<int,int>> repXY;repXY.reserve(R);for(uint64_t code:o4.reps){int h[16];for(int p=0;p<16;p++)h[p]=(code>>(4*p))&15;int cm[4]={};int s=0;for(int p=0;p<16;p++)for(int t=0;t<h[p];t++,s++)for(int r=0;r<4;r++)if((p>>r)&1)cm[r]|=1<<s;int ix[4];for(int r=0;r<4;r++){int m=cm[r];if(!(m&1))m=((1<<N)-1)^m;ix[r]=cutidx.at(m);}if(ix[0]>ix[1])swap(ix[0],ix[1]);if(ix[2]>ix[3])swap(ix[2],ix[3]);repXY.push_back({d2idx.at((uint64_t(ix[0])<<32)|ix[1]),d2idx.at((uint64_t(ix[2])<<32)|ix[3])});}
 vector<int>Acoef(R);auto t0=chrono::steady_clock::now();for(int oi=0;oi<R;oi++){auto [xi,yi]=repXY[oi];long long sum=0;for(auto&t:D3){int cx=fs.cls.at(hist5code(D2[xi],t.x,cuts));int cy=fs.cls.at(hist5code(D2[yi],t.x,cuts));sum=(sum+(long long)t.w*(Fval[cx]%MODP)%MODP*(Fval[cy]%MODP))%MODP;}Acoef[oi]=sum;if(oi%20==19)cerr<<"Acoef "<<oi+1<<" sec="<<chrono::duration<double>(chrono::steady_clock::now()-t0).count()<<"\n";}
 vector<vector<int>>L(R,vector<int>(R));for(int k=0;k<R;k++){auto [x,y]=repXY[k];for(auto&z:D2){int i=o4.cls.at(hist4code(D2[x],z,cuts));int j=o4.cls.at(hist4code(z,D2[y],cuts));int v=L[k][j]+Acoef[i];if(v>=MODP)v-=MODP;L[k][j]=v;}}
 auto modpow=[](long long a,int e){long long r=1;while(e){if(e&1)r=r*a%MODP;a=a*a%MODP;e>>=1;}return(int)r;};int rank=0;for(int c=0;c<R;c++){int p=-1;for(int r=rank;r<R;r++)if(L[r][c]){p=r;break;}if(p<0)continue;swap(L[p],L[rank]);int inv=modpow(L[rank][c],MODP-2);for(int j=c;j<R;j++)L[rank][j]=(long long)L[rank][j]*inv%MODP;for(int r=0;r<R;r++)if(r!=rank&&L[r][c]){int q=L[r][c];for(int j=c;j<R;j++){int v=L[r][j]-(long long)q*L[rank][j]%MODP;if(v<0)v+=MODP;L[r][j]=v;}}rank++;}
 cout<<"centralizer_left_multiplication_rank_mod_"<<MODP<<"="<<rank<<" of "<<R<<"\n";cout<<"therefore_cross_channel_rank="<<(rank==R?8001:-1)<<" of 8001\n";
}
